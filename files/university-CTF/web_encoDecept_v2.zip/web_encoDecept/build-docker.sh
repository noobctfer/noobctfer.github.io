docker build . -t web_encodecept
docker run -it -p 1337:1337 web_encodecept
