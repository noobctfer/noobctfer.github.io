import urllib.parse
from flask import Flask, send_from_directory, abort,render_template_string,request
import os
import urllib
import inspect
import json
import base64
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
def generate_jwks():
    # 1. 生成 RSA 密钥对
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=512
    )
    public_key = private_key.public_key()

    # 2. 提取公钥的模数 (n) 和指数 (e)
    public_numbers = public_key.public_numbers()
    n = public_numbers.n.to_bytes((public_numbers.n.bit_length() + 7) // 8, 'big')
    e = public_numbers.e.to_bytes((public_numbers.e.bit_length() + 7) // 8, 'big')
    print(private_key.private_numbers().d)
    jwk = {
        "kty": "RSA",                      
        "kid": "5cf5a00e-b3ff-4937-91a0-d25d2822084c",            
        "alg": "RS256",                   
        "use": "sig",                     
        "n": "q4cmLGtQvMFpoV5gLzTjldo0yRqIxSbosHYu6cAGV19StWndRQ80xI8ZsP3J8TyxGFxKn19ha+Vtpm4Sxryr3w==",         
        "e": "AQAB"            
    }
    jwks = {
        "keys": [jwk]
    }

    return json.dumps(jwks, indent=4)
app = Flask(__name__)
CURRENT_DIR = os.getcwd()
@app.route('/key', methods=["GET"])
def template():
    return generate_jwks(),200,{"Content-Type":"application/json"}

# 运行应用
if __name__ == '__main__':
    app.run(port=1234,debug=True)
